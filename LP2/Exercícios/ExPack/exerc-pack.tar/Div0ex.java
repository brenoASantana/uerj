public class Div0ex extends Exception {
    public Div0ex (String s) {
      super(s);
   }

}
