public class NumArgsEx extends Exception {
    public NumArgsEx (String s) { super(s);}

}
